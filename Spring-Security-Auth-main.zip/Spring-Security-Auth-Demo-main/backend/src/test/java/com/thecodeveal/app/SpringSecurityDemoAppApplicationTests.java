package com.thecodeveal.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityDemoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
